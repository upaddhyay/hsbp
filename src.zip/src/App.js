import './App.css';
import FooterComp from './components/common/FooterComp';
import HeaderComp from './components/common/HeaderComp';
import HomeComp from './components/HomeComp';

function App() {
  return (
    <div className="App">
     <HeaderComp />
     <HomeComp />
     <FooterComp />
    </div>
  );
}

export default App;
