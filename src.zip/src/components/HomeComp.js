import React from 'react'

function HomeComp() {
  return (
    <>
    <header>
        <div className="row">
            <div className="col-md-12">
                <div className="header-slider">
                    <div className="header-single-slider">
                        <figure>
                            <img src="assets/img/slider01.jpg" alt="" />
                            <figcaption>
                                <div className="content">
                                    <div className="container inner-content text-left">
                                        <h3>Welcome To Hantus Spa</h3>
                                        <h1>Beauty & Spa Wellness</h1>
                                        <p>The Spa at Sun Valley is a serene oasis amid all the exciting  activities our iconic valley has delivered for decades.</p>
                                        <a href="#" className="boxed-btn">Make an Appoinment</a>
                                    </div>
                                </div>
                            </figcaption>
                        </figure>
                    </div>
                    <div className="header-single-slider">
                        <figure>
                            <img src="assets/img/slider02.jpg" alt="" />
                            <figcaption>
                                <div className="content">
                                    <div className="container inner-content text-center">
                                        <h3>Welcome To Hantus Spa</h3>
                                        <h1>Beauty & Spa Wellness</h1>
                                        <p>The Spa at Sun Valley is a serene oasis amid all the exciting  activities our iconic valley has delivered for decades.</p>
                                        <a href="#" className="boxed-btn">Make an Appoinment</a>
                                    </div>
                                </div>
                            </figcaption>
                        </figure>
                    </div>
                    <div className="header-single-slider">
                        <figure>
                            <img src="assets/img/slider03.jpg" alt="" />
                            <figcaption>
                                <div className="content">
                                    <div className="container inner-content text-right">
                                        <h3>Welcome To Hantus Spa</h3>
                                        <h1>Beauty & Spa Wellness</h1>
                                        <p>The Spa at Sun Valley is a serene oasis amid all the exciting  activities our iconic valley has delivered for decades.</p>
                                        <a href="#" className="boxed-btn">Make an Appoinment</a>
                                    </div>
                                </div>
                            </figcaption>
                        </figure>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <section id="services" className="section-padding">
        <div className="container">
            <div className="row">
                <div className="col-lg-6 offset-lg-3 col-12 text-center">
                    <div className="section-title">
                        <h2>Our Services</h2>
                        <hr/>
                        <p>These are the services we provide, these makes us stand apart.</p>
                    </div>
                </div>
            </div>
            <div className="row">
                <div className="col-lg-4 col-md-6 col-sm-6 mb-5 mb-lg-0">                    
                    <div className="service-box text-center">                        
                        <figure>
                            <img src="img/bodycare.jpg" alt="" />
                           
                        </figure>
						<div className="inner-text">
							<h4>Body Care</h4>
							<p>Lorem Ipsum is simply dummy text of  the printing and typesetting.</p>
						</div>
                       
                    </div>
                </div>
                <div className="col-lg-4 col-md-6 col-sm-6 mb-5 mb-lg-0">                    
                    <div className="service-box text-center">                        
                        <figure>
                            <img src="img/skincare.jpg" alt="" />
                        </figure>
						<div className="inner-text">
							<h4>Skin Care</h4>
							<p>Lorem Ipsum is simply dummy text of  the printing and typesetting.</p>
						</div>
                      
                    </div>
                </div>
                <div className="col-lg-4 col-md-6 col-sm-6 mb-5 mb-sm-0">                    
                    <div className="service-box text-center">                        
                        <figure>
                            <img src="img/haircare.jpg" alt="" />
                        </figure>
						<div className="inner-text">
							<h4>Hair Care</h4>
							<p>Lorem Ipsum is simply dummy text of  the printing and typesetting.</p>
						</div>
                    </div>
                </div>
                
            </div>
        </div>
    </section>
    <section id="pricing" className="section-padding">
        <div className="container">
            <div className="row">
                <div className="col-lg-6 offset-lg-3 col-12 text-center">
                    <div className="section-title">
                        <h2>Pricing</h2>
                        <hr/>
                        <p>You can select a package from the list below to save more</p>
                    </div>
                </div>
            </div>

            <div className="row">
                <div className="col-lg-4 col-md-6 mb-5 mb-lg-0">
                    <div className="pricing-box text-center">
                        <h3>Silver Pack</h3>
                        <hr/>
                        <div className="price"><sup>$</sup> <span>55</span>/month</div>
                        <ul className="pricing-content">
                            <li>Nail Cutting & Styling</li>
                            <li>Hot Hair Coloring</li>
                            <li>Hot Oil Massage</li>
                            <li>Body Wraps</li>
                        </ul>
                        <a href="#" className="boxed-btn">Select Plan</a>
                    </div>
                </div>
                <div className="col-lg-4 col-md-6 mb-5 mb-lg-0">
                    <div className="pricing-box recomended text-center">
                        <div className="recomended-text"><span>Recommended</span></div>
                        <h3>Gold Pack</h3>
                        <hr/>
                        <div className="price"><sup>$</sup> <span>65</span>/month</div>
                        <ul className="pricing-content">
                            <li>Nail Cutting & Styling</li>
                            <li>Hot Hair Coloring</li>
                            <li>Hot Oil Massage</li>
                            <li>Body Wraps</li>
                            <li>Manicure</li>
                        </ul>
                        <a href="#" className="boxed-btn">Select Plan</a>
                    </div>
                </div>
                <div className="col-lg-4 col-md-6 offset-lg-0 offset-md-3">
                    <div className="pricing-box text-center">
                        <h3>Platinum Pack</h3>
                        <hr/>
                        <div className="price"><sup>$</sup> <span>105</span>/month</div>
                        <ul className="pricing-content">
                            <li>Nail Cutting & Styling</li>
                            <li>Hot Hair Coloring</li>
                            <li>Hot Oil Massage</li>
                            <li>Body Wraps</li>
                            <li>Manicure</li>
                            <li>Spa Therapy</li>
                        </ul>
                        <a href="#" className="boxed-btn">Select Plan</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section id="subscribe">
        <div className="container">
            <div className="row">
                <div className="col-lg-7 col-md-12 text-lg-left text-center mb-lg-0 mb-3">
                    <i className="ei ei-icon_mail"></i>
                    <h3>SIGN UP FOR NEWS AND OFFRERS</h3>
                    <p>Subcribe to lastest smartphones news & great deals we offer</p>
                </div>
                <div className="col-lg-5 col-md-12 text-center">
                    <form id="subscribe-form" action="#" method="POST">
                        <input type="email" name="email" id="subscribe-mail" placeholder="Email" required />
                        <button>Subscribe</button>
                    </form>
                </div>
            </div>
        </div>
    </section>
    </>
  )
}

export default HomeComp