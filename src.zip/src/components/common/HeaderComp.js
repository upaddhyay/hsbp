import React from 'react'

function HeaderComp() {
  return (
    <>    
    <div className="sidenav cart ">
        <div className="sidenav-header">
            <h3>Your cart</h3>
            <span className="fas fa-times close-sidenav"></span>
        </div>
        <div className="cart-item">
            <div className="cart-item-description">
                <h4 className="cart-item-name">Lorem Pellentesque Ipsum</h4>
                <p>$35.95</p>
            </div>
            <span className="cart-remove"><i className="fas fa-times"></i></span>
        </div>
        <div className="cart-item">
            <div className="cart-item-description">
                <h4 className="cart-item-name">Lorem Pellentesque Ipsum</h4>
                <p>$35.95</p>
            </div>
            <span className="cart-remove"><i className="fas fa-times"></i></span>
        </div>
        <div className="cart-item">
            <div className="cart-item-description">
                <h4 className="cart-item-name">Lorem Pellentesque Ipsum</h4>
                <p>$35.95</p>
            </div>
            <span className="cart-remove"><i className="fas fa-times"></i></span>
        </div>
        <div className="cart-item">
            <div className="cart-item-description">
                <h4 className="cart-item-name">Lorem Pellentesque Ipsum</h4>
                <p>$35.95</p>
            </div>
            <span className="cart-remove"><i className="fas fa-times"></i></span>
        </div>

        <div className="sub-total">
            <h6>Sub Total <span>$150.75</span></h6>
        </div>

        <div className="cart-buttons">
            <a href="#" className="boxed-btn">View Cart</a>
            <a href="#" className="boxed-btn fl">Check Out</a>
        </div>
    </div>
    <span className="cart-overlay"></span>

    <section className="navbar-wrapper">
        <div className="navbar-area sticky-nav">
            <div className="container">
                <div className="row">
                    <div className="col-lg-2 col-6">
                        <div className="logo main">
                            <a href="index.html"><img className="responsive" src="assets/img/logo.png" alt="Startkit" /></a>
                        </div>
                    </div>
                    <div className="col-lg-10 col-md-10 d-none d-lg-block text-right">
                        <nav className="main-menu">
                            <ul>
                                <li className="active">
                                    <a href="index.html">Home</a>
                                </li>
                                <li>
                                    <a href="services.html">Services</a>
                                </li>
                                <li className="c-dropdowns">
                                    <a href="">Portfolio</a>
                                    <ul className="cr-dropdown-menu">
                                        <li>
                                            <a href="portfolio-2-column.html">Portfolio 2 Column</a>
                                        </li>
                                        <li>
                                            <a href="portfolio-3-column.html">Portfolio 3 Column</a>
                                        </li>
                                        <li>
                                            <a href="portfolio-4-column.html">Portfolio 4 Column</a>
                                        </li>
                                    </ul>
                                </li>
                                <li className="c-dropdowns">
                                    <a href="">Pages</a>
                                    <ul className="cr-dropdown-menu">
                                        <li>
                                            <a href="about-us.html">About</a>
                                        </li>
                                        <li>
                                            <a href="pricing.html">Pricing</a>
                                        </li>
                                        <li>
                                            <a href="">Other Pages</a>
                                            <ul className="cr-sub-dropdown-menu">
                                                <li>
                                                    <a href="404.html">404 Page</a>
                                                </li>
                                                <li>
                                                    <a href="coming-soon.html">Coming Soon</a>
                                                </li>
                                            </ul>
                                        </li>
                                    </ul>
                                </li>
                                <li className="c-dropdowns">
                                    <a href="">Blog</a>
                                    <ul className="cr-dropdown-menu">
                                        <li>
                                            <a href="blog-left-sidebar.html">Blog Left Sidebar</a>
                                        </li>
                                        <li>
                                            <a href="blog-right-sidebar.html">Blog Right Sidebar</a>
                                        </li>
                                        <li>
                                            <a href="blog-full-width.html">Blog Full Width</a>
                                        </li>
                                        <li>
                                            <a href="blog-single.html">Blog Details</a>
                                        </li>
                                    </ul>
                                </li>

                                <li><a href="gallery.html">Gallery</a></li>
                                <li><a href="contact-us.html">Contact</a></li>
                                <li className="search-button">
                                    <div id="sb-search" className="sb-search " >
                                        <form>
                                            <input className="sb-search-input " onkeyup="buttonUp();" placeholder="Search"  type="search" value="" name="search" id="search" />
                                            <input className="sb-search-submit" type="submit"  value="" />
                                            <span className="sb-icon-search"><i className="ei ei-search"></i></span>
                                        </form>
                                    </div>
                                </li>
                                <li className="cart-icon">
                                    <div id="cd-cart-trigge" className="cart-icon-wrapper cart--open">
                                        <i className="ei ei-icon_bag_alt"></i>
                                        <span className="cart-count">2</span>
                                    </div>
                                </li>
                            </ul>
                        </nav>
                    </div>

                    <div className="col-6 text-right">
                        <ul className="mbl d-lg-none">
                            <li className="search-button">
                                <div className="sb-search">
                                    <form>
                                        <input className="sb-search-input" onkeyup="buttonUp();" placeholder="Search"  type="search" value="" name="search" />
                                        <input className="sb-search-submit" type="submit"  value="" />
                                        <span className="sb-icon-search"><i className="ei ei-search"></i></span>
                                    </form>
                                </div>
                            </li>
                            <li className="cart-icon">
                                <div className="cart-icon-wrapper cart--open">
                                    <i className="ei ei-icon_bag_alt"></i>
                                    <span className="cart-count">2</span>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div className="mobile-menu-area d-lg-none">
                <div className="container">
                    <div className="row">
                        <div className="col-md-12">
                            <div className="mobile-menu">
                                <nav className="mobile-menu-active">
                                    <ul>
                                        <li className="active">
                                            <a href="index.html">Home</a>
                                        </li>
                                        <li>
                                            <a href="services.html">Services</a>
                                        </li>
                                        <li className="c-dropdowns">
                                            <a href="">Portfolio</a>
                                            <ul className="cr-dropdown-menu">
                                                <li>
                                                    <a href="portfolio-2-column.html">Portfolio 2 Column</a>
                                                </li>
                                                <li>
                                                    <a href="portfolio-3-column.html">Portfolio 3 Column</a>
                                                </li>
                                                <li>
                                                    <a href="portfolio-4-column.html">Portfolio 4 Column</a>
                                                </li>
                                            </ul>
                                        </li>
                                        <li className="c-dropdowns">
                                            <a href="">Pages</a>
                                            <ul className="cr-dropdown-menu">
                                                <li>
                                                    <a href="about-us.html">About</a>
                                                </li>
                                                <li>
                                                    <a href="pricing.html">Pricing</a>
                                                </li>
                                                <li>
                                                    <a href="">Other Pages</a>
                                                    <ul className="cr-sub-dropdown-menu">
                                                        <li>
                                                            <a href="404.html">404 Page</a>
                                                        </li>
                                                        <li>
                                                            <a href="coming-soon.html">Coming Soon</a>
                                                        </li>
                                                    </ul>
                                                </li>
                                            </ul>
                                        </li>
                                        <li className="c-dropdowns">
                                            <a href="">Blog</a>
                                            <ul className="cr-dropdown-menu">
                                                <li>
                                                    <a href="blog-left-sidebar.html">Blog Left Sidebar</a>
                                                </li>
                                                <li>
                                                    <a href="blog-right-sidebar.html">Blog Right Sidebar</a>
                                                </li>
                                                <li>
                                                    <a href="blog-full-width.html">Blog Full Width</a>
                                                </li>
                                                <li>
                                                    <a href="blog-single.html">Blog Details</a>
                                                </li>
                                            </ul>
                                        </li>

                                        <li><a href="gallery.html">Gallery</a></li>
                                        <li><a href="contact-us.html">Contact</a></li>
                                    </ul>
                                </nav>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>        
    </section>
    </>
  )
}

export default HeaderComp