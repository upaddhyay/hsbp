import React from 'react'

function FooterComp() {
  return (
    <> <footer id="footer-widgets">
    <div className="container">

        <div className="row">
            <div className="col-lg-3 col-md-6 col-sm-6 mb-lg-0 mb-4">
                <aside className="widget widget_about">
                    <div className="footer-logo"><img src="assets/img/logo.png" alt="" /></div>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been.</p>
                    <ul className="widget-info">
                        <li><i className="fas fa-map-marker"></i>198 Collins St, Melbourne, NY</li>
                        <li><i className="fas fa-phone"></i>12) 345 678 910</li>
                        <li><i className="fas fa-envelope"></i><a href="/cdn-cgi/l/email-protection" className="__cf_email__" data-cfemail="8eebe3efe7e2ceede1e3feefe0f7e0efe3eba0ede1e3">[email&#160;protected]</a></li>
                    </ul>
                </aside>
            </div>
            <div className="col-lg-3 col-md-6 col-sm-6 mb-lg-0 mb-md-0 mb-4">
                <aside className="widget widget_recent">
                    <h4 className="widget-title"><img src="assets/img/section-icon.png" alt="" />Latest News</h4>
                    <ul>
                        <li className="latest-news">
                            <a href="#">
                                <h6>F&O cues: Nifty 11100 Put adds 4.6 lakh shares in</h6>
                                <p>Thurday, 25th January 2018</p>
                            </a>
                        </li>
                        <li className="latest-news">
                            <a href="#">
                                <h6>Bharat Bijlee touched 52-week high on strong Q3</h6>
                                <p>Thurday, 25th January 2018</p>
                            </a>
                        </li>
                    </ul>
                </aside>
            </div>
            <div className="col-lg-3 col-md-6 col-sm-6 mb-lg-0 mb-4">
                <aside className="widget widget_links">
                    <h4 className="widget-title"><img src="assets/img/section-icon.png" alt="" />Quick Link</h4>
                    <ul>
                        <li><a href="#">Home</a></li>
                        <li><a href="#">About</a></li>
                        <li><a href="#">Service</a></li>
                        <li><a href="#">Blog</a></li>
                        <li><a href="#">Project</a></li>
                    </ul>
                    <ul>
                        <li><a href="#">Nail Care</a></li>
                        <li><a href="#">Massage</a></li>
                        <li><a href="#">Hair Cut</a></li>
                        <li><a href="#">Waxing</a></li>
                        <li><a href="#">Make Up</a></li>
                    </ul>
                </aside>
            </div>
            <div className="col-lg-3 col-md-6 col-sm-6">
                <aside className="widget widdget-instagram">
                    <h4 className="widget-title"><img src="assets/img/section-icon.png" alt="" />Instagram</h4>
                    <ul className="instagram-photos">                                
                        <li>
                            <img src="assets/img/instagram01.jpg" alt="" />
                            <div className="instagram-overlay">
                                <a href="#">+</a>
                            </div>
                        </li>                                
                        <li>
                            <img src="assets/img/instagram02.jpg" alt="" />
                            <div className="instagram-overlay">
                                <a href="#">+</a>
                            </div>
                            
                        </li>                                
                        <li>
                            <img src="assets/img/instagram03.jpg" alt="" />
                            <div className="instagram-overlay">
                                <a href="#">+</a>
                            </div>
                        </li>                               
                        <li>
                            <img src="assets/img/instagram04.jpg" alt="" />
                            <div className="instagram-overlay">
                                <a href="#">+</a>
                            </div>
                        </li>                                
                        <li>
                            <img src="assets/img/instagram05.jpg" alt="" />
                            <div className="instagram-overlay">
                                <a href="#">+</a>
                            </div>
                            
                        </li>                                
                        <li>
                            <img src="assets/img/instagram06.jpg" alt="" />
                            <div className="instagram-overlay">
                                <a href="#">+</a>
                            </div>
                        </li>
                    </ul>
                </aside>
            </div>
        </div>

    </div>
</footer>
    <section id="footer-copyright">
    <div className="container">
        <div className="row">
            <div className="col-lg-6 col-12 text-lg-left text-center mb-lg-0 mb-3 copyright-text">
                <ul>
                    <li><a href="#">&copy; 2018 Nayra Themes </a></li>
                    <li><a href="#">Terms & Conditions</a></li>
                    <li><a href="#">Privacy Policy</a></li>
                    <li><a href="#">Contact</a></li>
                </ul>
            </div>
            <div className="col-lg-6 col-12">
                <ul className="text-lg-right text-center payment-method">
                    <li><a href="#"><img src="assets/img/mastercard.png" alt="" /></a></li>
                    <li><a href="#"><img src="assets/img/shopify.png" alt="" /></a></li>
                    <li><a href="#"><i className="fab fa-paypal"></i></a></li>
                    <li><a href="#"><i className="fab fa-cc-visa"></i></a></li>
                </ul>
                <a href="#" className="scrollup"><i className="fas fa-arrow-up"></i></a>
            </div>
        </div>
    </div>
</section>
</>
  )
}

export default FooterComp